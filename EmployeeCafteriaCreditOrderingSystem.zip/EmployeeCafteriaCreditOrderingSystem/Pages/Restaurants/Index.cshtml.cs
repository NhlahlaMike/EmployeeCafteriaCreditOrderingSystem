using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EmployeeCafteriaCreditOrderingSystem.Pages.Restaurants
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
