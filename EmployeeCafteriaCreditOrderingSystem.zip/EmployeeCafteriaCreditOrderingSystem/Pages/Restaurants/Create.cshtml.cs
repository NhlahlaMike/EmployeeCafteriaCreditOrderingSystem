using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EmployeeCafteriaCreditOrderingSystem.Pages.Restaurants
{
    public class CreateModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
