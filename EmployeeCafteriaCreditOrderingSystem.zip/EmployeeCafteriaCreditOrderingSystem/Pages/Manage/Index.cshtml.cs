using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace EmployeeCafteriaCreditOrderingSystem.Pages.Manage
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
